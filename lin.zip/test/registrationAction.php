<?php
// Start the session
session_start();
?>
<?php

$servername="localhost";
$dusername="root";
$dpassword="";
$dbname="estore";

/*connect to database*/
$conn= new mysqli($servername,$dusername,$dpassword,$dbname);

if ($conn->connect_error)
{
    die ("connect failed:".$conn->connect_error);
}
else
{
   
$fisrtname=$_POST["first_name"];

$lastname=$_POST["last_name"];

$address=$_POST["address"];
$username=$_POST["username"];
$password=password_hash($_POST["password"],PASSWORD_DEFAULT);
$dob=$_POST["dob"];
    $pnumber=$_POST["contact_no"];
    $email=$_POST["email"];
$email=$_POST["email"];


    
    $query = "INSERT INTO customer (fName,lName,address,username,password,contactNo,dob,email) VALUES
    ('".$fisrtname."','".$lastname."','".$address."','".$username."','".$password."','".$pnumber."','".$dob."','".$email."')";

$result = mysqli_query($conn,$query);

if(!$result){
    echo "<p>something is wrong with", $query,"</p>";
}
else
{
    echo"<p> successfully added</p>";
    
}}
  
mysqli_close($conn);
    
?>