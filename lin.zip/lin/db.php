<?php

$servername="localhost";
$dusername="root";
$dpassword="";
$dbname="estore";

/*connect to database*/
$conn= new mysqli($servername,$dusername,$dpassword,$dbname);

if ($conn->connect_error)
{
    die ("connect failed:".$conn->connect_error);
}
?>