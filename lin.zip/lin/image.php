
<?php

$servername="localhost";
$dusername="root";
$dpassword="";
$dbname="estore";

/*connect to database*/
$conn= new mysqli($servername,$dusername,$dpassword,$dbname);

if ($conn->connect_error)
{
    die ("connect failed:".$conn->connect_error);
}




 $query = "SELECT * From product order by rand() limit 0,9 "; 
$result = mysqli_query($conn,$query);
$row=mysqli_fetch_array($result);
while($row=mysqli_fetch_array($result)){
    $pId= $row["productId"];
    $pName= $row["pName"];
    $pAddress= $row["picAddress"];
    
    echo 
        "<div class='col-sm-4'>
<div class='panel panel-primary' style='height:370px;'> <div class='panel-heading'>$pId</div>
<div class='panel-body' ><img src='$pAddress' class='img-thumbnail  class='img-responsive' style='width:100%' alt='Image''></div>
<div class='panel-footer'>$pName</div>
</div> </div> 
";
    
}



    mysqli_close($conn);
   
?>