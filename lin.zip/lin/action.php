<?php
include "db.php";
$query="SELECT * FROM catagory ";
$results= mysqli_query($conn, $query);

if (mysqli_num_rows($results) > 0)
{
    
echo "<li><a href='#'><h4>Filter By Categories</h4></a></li>";
while($row = mysqli_fetch_array($results)) 
{ 
$catagoryId = $row["catagoryId"]; 
$cName = $row["cName"];
echo "<li><a href='#' class='category' cid='$catagoryId' >$cName</a></li>";
}
}

?>