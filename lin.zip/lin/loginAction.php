<?php
// Start the session
session_start();
?>
<?php

$servername="localhost";
$dusername="root";
$dpassword="";
$dbname="estore";

/*connect to database*/
$conn= new mysqli($servername,$dusername,$dpassword,$dbname);

if ($conn->connect_error)
{
    die ("connect failed:".$conn->connect_error);
}


$username=$_POST["username"];

$password=$_POST["password"];


 $query = "SELECT password , fName From customer where username= '".$username."' "; 
$result = mysqli_query($conn,$query);
$row=mysqli_fetch_array($result);

if (mysqli_num_rows($result) > 0) {
if (password_verify($password,$row['password'])){
      echo "<p> welcome ".$row['fName']."  </p>";
    $_SESSION['username']=$row['fName'];
     header ('Location:http://localhost/lin/index.php');
    unset($_SESSION['password']);
}


else
{
   echo "<p>password is wrong</p>";
    $_SESSION['password']="Password is wrong";
    header ('Location:http://localhost/lin/login.php');
    
}
}

    mysqli_close($conn);
   
?>