<?php
include "db.php";

// get the q parameter from URL
$pid = $_REQUEST["q"];


$sql = "SELECT * FROM product INNER JOIN pictures ON product.productId=pictures.productId WHERE product.productId = ".$pid;
$results = mysqli_query($connection,$sql);

if(mysqli_num_rows($results)>0){

    while ($row = mysqli_fetch_array($results)){
       
        $prod_pic1 = $row["link1"];
         $prod_pic2 = $row["link2"];
         $prod_pic3 = $row["link3"];

        echo '
  <div class="item active">
            <div class="ImageContainer">
              <img src="'.$prod_pic1.'" alt="Pic1" ></div>
      </div>

      <div class="item" >
           <div class="ImageContainer"><img src="'.$prod_pic2.'" alt="Pic2">
          </div>
      </div>

      <div class="item">
             <div class="ImageContainer">
                 <img src="'.$prod_pic3.'" alt="Pic3">
          </div>
      </div>';
    }
}
?>