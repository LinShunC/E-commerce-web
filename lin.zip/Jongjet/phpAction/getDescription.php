<?php
include "db.php";

// get the q parameter from URL
$pid= $_REQUEST["q"];
$cat_sql = "SELECT * FROM product WHERE productId=".$pid;

$results = mysqli_query($connection,$cat_sql);

if(mysqli_num_rows($results)>0){

       while ($row = mysqli_fetch_array($results)){

        echo "".$row['ProductDescription']."";}
    
}
?>