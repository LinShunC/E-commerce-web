<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Homepage</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        
       

        <link rel="stylesheet" type="text/css" href="css/navbarStyle.css">
        <link rel="stylesheet" type="text/css" href="css/mainStyle.css">
        <script>
          $(document).ready(function(){
  $(".test").click(function(){
 window.open('productsView.php', '_self');         
  });
});</script>

    </head>
<?php
session_start();
?>


           

    <body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="50">
<nav class="navbar navbar-default">
    <div class="container-fluid">

        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#"><img class="img-responsive img-rounded" alt="logo" src="Pictures/logo.png"></a>
        </div>

        <div class="collapse navbar-collapse" id="myNavbar">
            
            <ul class="nav navbar-nav navbar-right">
                <li class="dropdown">

                    <?php 
                    
                    if (isset($_SESSION['username'])){ 
                        
                    ?>

                    <a class="dropdown-toggle" data-toggle="dropdown"  href="#"><span class="glyphicon glyphicon-user"></span>
                        <?php echo $_SESSION['username']; ?>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a href="
                            <?php session_destroy(); ?>
                            ">log out</a>
                        </li>
                    </ul>

                    <?php }else{ ?>

                    <a class="dropdown-toggle" data-toggle="dropdown"  href="#"><span class="glyphicon glyphicon-user"></span> Your Account</a>
                    <ul class="dropdown-menu">
                        <li><a href="login.php">log in </a></li>
                        <li><a href="registration.php">registration</a></li>

                    </ul>

                    <?php } ?>



                </li>
                <li><a href="#"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
            </ul>
            <form class="navbar-form navbar-right" action="/action_page.php">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search">
                    <div class="input-group-btn">
                        <button class="btn" type="submit" style="padding: 6px 10px; vertical-align: top;margin-left: 0px">
                            <span class="glyphicon glyphicon-search"></span>
                        </button>
                    </div>
                </div>
            </form>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="index.php">HOME</a></li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Google</a>
                    <ul class="dropdown-menu">
<li id="google3" onclick="loadPrice('1'),loadDescription('1'),loadImage('1'),loadRelated('1')"

>
    <a href="productsView.php">Google Pixel 3</a>
                        </li>
                        <li onclick="loadPrice('2'),loadDescription('2'),loadImage('2'),loadRelated('2')"><a href="#">Google Pixel 3XL</a></li>
                        <li><a href="#">All</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Apple</a>
                    <ul class="dropdown-menu">
                        <li onclick="loadPrice('3'),loadDescription('3'),loadImage('3'),loadRelated('3')" class="test" ><a href="#">Apple iPhone XS Max</a></li>
                        <li onclick="loadPrice('4'),loadDescription('4'),loadImage('4'),loadRelated('4')" class="test"  ><a href="#">Apple iPhone 8</a></li>
                        <li><a href="#">All</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Samsung</a>
                    <ul class="dropdown-menu">
                        <li onclick="loadPrice('5'),loadDescription('5'),loadImage('5'),loadRelated('5')"><a href="#">Samsung Galaxy S9+</a></li>
                        <li onclick="loadPrice('6'),loadDescription('6'),loadImage('6'),loadRelated('6')"><a href="#">Samsung Galaxy S10</a></li>
                        <li><a href="#">All</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Oppo</a>
                    <ul class="dropdown-menu">
                        <li onclick="loadPrice('7'),loadDescription('7'),loadImage('7'),loadRelated('7')"><a href="#">OPPO Find X</a></li>
                        <li onclick="loadPrice('8'),loadDescription('8'),loadImage('8'),loadRelated('8')"><a href="#">OPPO Reno Z</a></li>
                        <li><a href="#">All</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">HUAWEI</a>
                    <ul class="dropdown-menu">
                        <li onclick="loadPrice('9'),loadDescription('9'),loadImage('9'),loadRelated('9')"><a href="#">Huawei Nova 3e</a></li>
                        <li onclick="loadPrice('10'),loadDescription('10'),loadImage('10'),loadRelated('10')"><a href="#">Huawei P30 Pro</a></li>
                        <li><a href="#">All </a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">LG</a>
                    <ul class="dropdown-menu">
                        <li onclick="loadPrice('11'),loadDescription('11'),loadImage('11'),loadRelated('11')"><a href="#">LG V30+</a></li>
                        <li onclick="loadPrice('12'),loadDescription('12'),loadImage('12'),loadRelated('12')"><a href="#">LG V40 ThinQ </a></li>
                        <li><a href="#">All</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">NOKIA</a>
                    <ul class="dropdown-menu">
                        <li onclick="loadPrice('13'),loadDescription('13'),loadImage('13'),loadRelated('13')"><a href="#">Nokia 8.1</a></li>
                        <li onclick="loadPrice('14'),loadDescription('14'),loadImage('14'),loadRelated('14')"><a href="#">Nokia 9</a></li>
                        <li><a href="#">All</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Accessories</a>
                    <ul class="dropdown-menu">
                        <li><a href="#">Screen Protector</a></li>
                        <li><a href="#">Phone Chargers  </a></li>
                        <li><a href="#">All</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
        <div id="includedContent"></div>

        <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1"></li>
                <li data-target="#myCarousel" data-slide-to="2"></li>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
                <div class="item active">
                    <img src="Pictures/promotion1.jpg" alt="New York">
                    <div class="carousel-caption">
                        <h3>New York</h3>
                        <p>The atmosphere in New York is lorem ipsum.</p>
                    </div>
                </div>

                <div class="item" >
                    <img src="Pictures/promotion1.jpg" alt="Chicago">
                    <div class="carousel-caption">
                        <h3>Chicago</h3>
                        <p>Thank you, Chicago - A night we won't forget.</p>
                    </div>
                </div>

                <div class="item">
                    <img src="Pictures/promotion1.jpg" alt="Los Angeles">
                    <div class="carousel-caption">
                        <h3>LA</h3>
                        <p>Even though the traffic was a mess, we had the best time playing at Venice Beach!</p>
                    </div>
                </div>
            </div>

            <!-- Left and right controls -->
            <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>



        <div class = "mainContent row">



            <div class="row" id="content">
                <div class="container">

                    <div class="row">
                        <?php 
                        include "phpAction/mainPVAction.php";
                        ?>
                    </div>

                </div>

            </div>
        </div>




        <!-- Footer -->
        <footer class="text-center">
            <a class="up-arrow" href="#myPage" data-toggle="tooltip" title="TO TOP">
                <span class="glyphicon glyphicon-chevron-up"></span>
            </a><br><br>
            <p>Bootstrap Theme Made By <a href="https://www.w3schools.com" data-toggle="tooltip" title="Visit w3schools">www.w3schools.com</a></p>
        </footer>

        <script>
            $(document).ready(function(){
                // Initialize Tooltip
                $('[data-toggle="tooltip"]').tooltip();

                // Add smooth scrolling to all links in navbar + footer link
                $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

                    // Make sure this.hash has a value before overriding default behavior
                    if (this.hash !== "") {

                        // Prevent default anchor click behavior
                        event.preventDefault();

                        // Store hash
                        var hash = this.hash;

                        // Using jQuery's animate() method to add smooth page scroll
                        // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
                        $('html, body').animate({
                            scrollTop: $(hash).offset().top
                        }, 900, function(){

                            // Add hash (#) to URL when done scrolling (default click behavior)
                            window.location.hash = hash;
                        });
                    } // End if
                });
            })
        </script>



    </body>
</html>
